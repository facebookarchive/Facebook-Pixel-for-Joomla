1.0.3 (December 13, 2018)
* Add "ViewContent", "AddToCart", "InitiateCheckout" and "Purchase" events for J2Store shopping cart plugin.

1.0.2 (December 3, 2018)
* Fix install name to "Official Facebook Pixel".

1.0.1 (November 20, 2018)
* Add "Lead" event for Joomla contact form.

1.0.0 (September 24, 2018)
* Launch plugin with the capability of sending "PageView" event.